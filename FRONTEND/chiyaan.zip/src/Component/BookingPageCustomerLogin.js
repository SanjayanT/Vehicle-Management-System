import React from "react";
import "./Home.css";
import "./BookingPage.js";
import "./BookingPage.css";
//import imgSrc from "./customer.png";
//import imgSrc1 from "./manager.png";
//import imgSrc2 from "./wipe.jpg";

export default function BookingPageCustomerLogin() {
  return (
    <div>
      <h1>helloooooooooooooooooooooooo</h1>
    </div>
  );
}
