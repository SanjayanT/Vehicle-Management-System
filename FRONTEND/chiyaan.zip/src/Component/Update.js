import React from "react";
import { BrowserRouter } from "react-router-dom";
// import "./Res.css";
export default function Update(){
    return(
        <div>
            <h1 style={{color:"red"}}>Update supplier from here</h1>
        </div>
    )
}
