import React from "react";
import { BrowserRouter } from "react-router-dom";


export default function Delete(){
    return(
        <div>
            <h1 style={{color:"red"}}>Delete Supplier from here</h1>
        </div>
    )
    
}